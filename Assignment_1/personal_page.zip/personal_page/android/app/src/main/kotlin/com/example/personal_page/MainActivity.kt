package com.example.personal_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
